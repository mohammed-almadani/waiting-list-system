



package finaaaaal;

import javax.swing.*;  
import java.awt.*; 
import java.io.FileWriter;
import java.io.IOException;

public class ContactInfo extends JPanel 
{
    JLabel label;
    JLabel name; 
    JLabel phoneNumber;
    JLabel email; 
    JTextField nameEntry;
    JTextField phoneNumberEntry;
    JTextField emailEntry;
    
    public ContactInfo()
    {
        setLayout(new GridLayout(7, 1));
        setBorder(BorderFactory.createLineBorder(Color.RED, 3));
        
        label = new JLabel("Fill in contact information:");
        name = new JLabel("Name: ");
        phoneNumber = new JLabel("Phone Number: ");
        email = new JLabel("Email: ");
        nameEntry = new JTextField(50);
        phoneNumberEntry = new JTextField(10);
        emailEntry = new JTextField(50);
        
        setBackground(Color.WHITE);
        label.setBackground(Color.WHITE);
        name.setBackground(Color.WHITE);
        phoneNumber.setBackground(Color.WHITE);
        email.setBackground(Color.WHITE);
        label.setForeground(Color.BLACK);
        name.setForeground(Color.BLACK);
        nameEntry.setBackground(Color.WHITE);
        phoneNumber.setForeground(Color.BLACK);
        phoneNumberEntry.setBackground(Color.WHITE);
        email.setForeground(Color.BLACK);
        emailEntry.setBackground(Color.WHITE);
        
        add(label);
        add(name);
        add(nameEntry);
        add(phoneNumber);
        add(phoneNumberEntry);
        add(email);
        add(emailEntry);
    }
    public String getContactInfo() throws IOException
    {
        String ci = " ";
        
        FileWriter filewriter = new FileWriter("Information.txt",true);
        filewriter.write("\n" + name.getText()+ nameEntry.getText());
        filewriter.write("\n" + phoneNumber.getText()+ phoneNumberEntry.getText());
        filewriter.write("\n" + email.getText()+ emailEntry.getText());
        filewriter.close();
        
        return ci;
    }
}