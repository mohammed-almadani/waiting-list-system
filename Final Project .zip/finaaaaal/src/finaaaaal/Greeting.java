


package finaaaaal;

import javax.swing.*;  
import java.awt.*;

public class Greeting extends JPanel
{
    private JLabel greeting; 
    
    public  Greeting()
    {
        ImageIcon image = new ImageIcon("fast-food.png");
        greeting = new JLabel(" "); 
        greeting.setIcon(image);
        setBorder(BorderFactory.createLineBorder(Color.RED, 3));
        setBackground(Color.WHITE);
        greeting.setForeground(Color.BLACK);
        add(greeting);
       
    }
}

