


package finaaaaal;
import javax.swing.*;  
import java.awt.*; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CelebrationTable extends JPanel
{
    private JLabel label;
    private JRadioButton yes;
    private JRadioButton no;
    private ButtonGroup bg; 
    private JLabel notice;
    
    public CelebrationTable()
    {
        setLayout(new GridLayout(4, 1));
        setBorder(BorderFactory.createLineBorder(Color.RED, 3));
        
        label = new JLabel("Include a celebration table:");
        yes = new JRadioButton("Yes");
        no = new JRadioButton("No");
        notice = new JLabel("(celebration fees will be added to bill)");
        
        bg = new ButtonGroup();
        bg.add(yes);
        bg.add(no);
        
        setBackground(Color.WHITE);
        label.setBackground(Color.WHITE);
        yes.setBackground(Color.WHITE);
        no.setBackground(Color.WHITE);
        notice.setBackground(Color.WHITE);
        label.setForeground(Color.BLACK);
        yes.setForeground(Color.BLACK);
        no.setForeground(Color.BLACK);
        notice.setForeground(Color.BLACK);
        
        yes.addActionListener(new ButtonListener());
        
        add(label);
        add(yes);
        add(no);
        add(notice);
    }
    public String getCelebrationTable() 
    {
        String ct = " ";
        if(yes.isSelected())
        {
            ct = "\nCelebration table: Included\n";
        }
        else if(no.isSelected())
        {
            ct = "\nCelebration table: Not included\nDessert: None\n";
        }
        return ct;
    }
    private void pack() 
    {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    private class ButtonListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent ae)
        {
            if(yes.isSelected())
            {
                Dessert ob=new Dessert();
                ob.setSize(500, 500);
            }
            else
            {
                System.exit(0);
            }
        } 
    }
}