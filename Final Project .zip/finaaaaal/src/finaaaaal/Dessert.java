


package finaaaaal;

import javax.swing.*;  
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Dessert extends JFrame 
{
    private JLabel label;
    private JRadioButton checkbox1;
    private JRadioButton checkbox2;
    private JRadioButton checkbox3;
    private JRadioButton checkbox4;
    private ButtonGroup bg;
    private JButton button;
    private ImageIcon icon_Donut = new ImageIcon("donut.png");
    private ImageIcon icon_cup = new ImageIcon("cupcake.png");
    private ImageIcon icon_ice = new ImageIcon("ice-cream-cup.png");
    private ImageIcon icon_cake = new ImageIcon("black-forest.png");
    private JLabel image=new JLabel();
    private JPanel radioPanel = new JPanel();
    private JPanel button_panel = new JPanel();
    private JPanel icon_panel = new JPanel();
    public Dessert()
    {
        setTitle("Celebration Dessert");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
  
        radioPanel.setLayout(new GridLayout(6,0));
        label= new JLabel("Choose a dessert:");
        checkbox1 = new JRadioButton("Donut");        
        checkbox2 = new JRadioButton("Cup Cake");      
        checkbox3 = new JRadioButton("Ice creem");      
        checkbox4 = new JRadioButton("Chocolate Cake");
        
        JPanel panel = new JPanel();
        button = new JButton ("Done");
        
        bg = new ButtonGroup();
        bg.add(checkbox1);
        bg.add(checkbox2);
        bg.add(checkbox3);
        bg.add(checkbox4);
        
        button.setBackground(Color.LIGHT_GRAY);
        button.addActionListener(new buttonListener());
        checkbox1.addActionListener(new RadioListener());
        checkbox2.addActionListener(new RadioListener());
        checkbox3.addActionListener(new RadioListener());
        checkbox4.addActionListener(new RadioListener());
        
        icon_panel.add(image);
        radioPanel.add(label);
        radioPanel.add(checkbox1);
        radioPanel.add(checkbox2);       
        radioPanel.add(checkbox3);       
        radioPanel.add(checkbox4);  
        button_panel.add(button, BorderLayout.CENTER);
        add(button_panel, BorderLayout.SOUTH);
        add(radioPanel, BorderLayout.WEST);
        add(icon_panel, BorderLayout.CENTER);
        setVisible(true);
    } 
    public String getDessert() 
    {
        String d = " "; 
        
        if(checkbox1.isSelected())
        {
            d = "Dessert: Donut";
        }
        else if(checkbox2.isSelected())
        {
            d = "Dessert: Chocolate truffle balls";
        }
       else if(checkbox3.isSelected())
        {
            d = "Dessert: Ice cream";
        }
        else if(checkbox4.isSelected())
        {
            d = "Dessert: Cake";
        }
        return d;
    }
    private class buttonListener implements ActionListener
    {
      
        public void actionPerformed(ActionEvent ae) 
        {
            FileWriter fw;
            try 
            {
                fw = new FileWriter("Information.txt" ,true); 
                try (PrintWriter pw = new PrintWriter(fw)) 
                {
                    pw.println(getDessert());
                }
            } 
            catch (IOException ex) 
            {
                Logger.getLogger(Dessert.class.getName()).log(Level.SEVERE, null, ex);
            }
            dispose();
        }    
    } 
    
   
         private class RadioListener implements ActionListener {

        public void actionPerformed(ActionEvent ae) {

            if (checkbox1.isSelected()) {
                image.setIcon(icon_Donut);
            }
            else if (checkbox2.isSelected()) {
                image.setIcon(icon_cup);
            }
            else if (checkbox3.isSelected()) {
                image.setIcon(icon_ice);

            }
            else if (checkbox4.isSelected()) {
                image.setIcon(icon_cake);
            }
            
        }

    }   
                
}