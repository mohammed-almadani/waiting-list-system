


package finaaaaal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MSRestaurant extends JFrame 
{
    private Greeting g;
    private ContactInfo ci;
    private Table t;
    private CelebrationTable ct;
    private Menu m;
    private JPanel panel1;
    private JPanel panel2;
    private JPanel panel3;
    private JButton button1;
    private JButton button2;
    private FileWriter filewriter;
    private JMenuBar menuBar;
    private JMenu fileMenu;
    private JMenuItem exitItem;
    

    public MSRestaurant() throws IOException 
    {
        setLayout(new BorderLayout());
        setTitle("M&S Restaurant");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();
        g = new Greeting();
        ci = new ContactInfo();
        t = new Table();
        ct = new CelebrationTable();
        m = new Menu();
        button1 = new JButton("Reserve table");
        button2 = new JButton("View Booking");
        filewriter = new FileWriter("Information.txt");

        panel1.setBackground(Color.WHITE);
        panel2.setBackground(Color.WHITE);
        panel3.setBackground(Color.WHITE);
        button1.setBackground(Color.LIGHT_GRAY);
        button2.setBackground(Color.LIGHT_GRAY);

        panel1.add(g, BorderLayout.WEST);
        panel1.add(ci, BorderLayout.CENTER);
        panel2.add(t, BorderLayout.WEST);
        panel2.add(m, BorderLayout.CENTER);
        panel2.add(ct, BorderLayout.EAST);
        panel3.add(button1, BorderLayout.WEST);
        panel3.add(button2, BorderLayout.CENTER);

        button1.addActionListener(new Button1Listener());
        button2.addActionListener(new Button2Listener());

        buildMenuBar();

        add(panel1, BorderLayout.NORTH);
        add(panel2, BorderLayout.CENTER);
        add(panel3, BorderLayout.SOUTH);

        pack();
        setVisible(true);
    }
    private void buildMenuBar() 
    {
        menuBar = new JMenuBar();
        buildfileMenu();
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }
    private void buildfileMenu() 
    {
        exitItem = new JMenuItem("Exit");
        exitItem.setMnemonic(KeyEvent.VK_X);
        exitItem.addActionListener(new ExitListener());
        fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        fileMenu.add(exitItem);
    }
    private class ExitListener implements ActionListener 
    {
        @Override
        public void actionPerformed(ActionEvent ae) 
        {
            System.exit(0);
        }
    }
    private class Button1Listener implements ActionListener 
    {
        @Override
        public void actionPerformed(ActionEvent ae) 
        {
            if (ae.getActionCommand() == button1.getActionCommand()) 
            {
                try 
                {
                    filewriter = new FileWriter("Information.txt", true);
                    filewriter.write(ci.getContactInfo());
                    filewriter.write(t.getTable());
                    filewriter.write(m.getMenu());
                    filewriter.write(ct.getCelebrationTable());
                    filewriter.close();
                    JOptionPane.showMessageDialog(null, "Reserve table saved");
                } 
                catch (Exception e) 
                {
                    JOptionPane.showMessageDialog(null, e + "");
                }
            }
        }
    }
    private class Button2Listener implements ActionListener 
    {
        @Override
        public void actionPerformed(ActionEvent ae) 
        {
            try 
            {
                View v = new View();
                v.setSize(500, 500);
                v.setVisible(true);
            } 
            catch (FileNotFoundException e) 
            {
                throw new RuntimeException(e);
            }
        }
    }
    public static void main(String[] args) throws IOException 
    {
        new MSRestaurant();
    }
}
