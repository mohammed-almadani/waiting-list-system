


package finaaaaal;

import javax.swing.*;  
import java.awt.*;

public class Menu extends JPanel
{
    private JLabel label;
    private JRadioButton breakfastMenu;
    private JRadioButton lunchMenu;
    private JRadioButton dinnerMenu;
    private ButtonGroup bg;
    
    public Menu()
    {
        setLayout(new GridLayout(5, 1));
        setBorder(BorderFactory.createLineBorder(Color.RED, 3));
        
        label = new JLabel("Choose a menu:");
        breakfastMenu = new JRadioButton("Breakfast Menu", true);
        lunchMenu = new JRadioButton("Lunch Menu");
        dinnerMenu = new JRadioButton("Dinner Menu");  
        
        bg = new ButtonGroup();
        bg.add(breakfastMenu);
        bg.add(lunchMenu);
        bg.add(dinnerMenu);
        
        setBackground(Color.WHITE);
        label.setBackground(Color.WHITE);
        breakfastMenu.setBackground(Color.WHITE);
        lunchMenu.setBackground(Color.WHITE);
        dinnerMenu.setBackground(Color.WHITE);
        label.setForeground(Color.BLACK);
        breakfastMenu.setForeground(Color.BLACK);
        lunchMenu.setForeground(Color.BLACK);
        dinnerMenu.setForeground(Color.BLACK);
        
        add(label);
        add(breakfastMenu);
        add(lunchMenu);
        add(dinnerMenu);
    }
    public String getMenu() 
    {
        String m = " "; 
        
        if(breakfastMenu.isSelected())
        {
            m = "\nMenu: Breakfast";
        }
        else if(lunchMenu.isSelected())
        {
            m = "\nMenu: Lunch";
        }
        else if(dinnerMenu.isSelected())
        {
            m = "\nMenu: Dinner";
        }
        return m;
    }
}