


package finaaaaal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;

public class View extends JFrame
{
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JLabel label4;
    private JLabel label5;
    private JLabel label6;
    private JLabel label7;
    private JButton button;
    private JPanel panel;
    
    public View() throws FileNotFoundException
    {
        setTitle("Reservation");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(8,1));

        File f = new File("Information.txt");
        Scanner scan = new Scanner(f);
        String str1 = "";
        String str2 = "";
        String str3 = "";
        String str4 = "";
        String str5 = "";
        String str6 = "";
        String str7 = "";
        
        while(scan.hasNext())
        {
            str1 = scan.nextLine();
            str2 = scan.nextLine();
            str3 = scan.nextLine();
            str4 = scan.nextLine();
            str5 = scan.nextLine();
            str6 = scan.nextLine();
            str7 = scan.nextLine();
        }
        scan.close();

        label1 = new JLabel(str1);
        label2 = new JLabel(str2);
        label3 = new JLabel(str3);
        label4 = new JLabel(str4);
        label5 = new JLabel(str5);
        label6 = new JLabel(str6);
        label7 = new JLabel(str7);
        button = new JButton("Done");
        panel = new JPanel();
        panel.add(button, BorderLayout.CENTER);
        
        button.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                dispose();
            }
        });
        
        button.setBackground(Color.RED);
        
        add(label2);
        add(label3);
        add(label4);
        add(label5);
        add(label6);
        add(label7);
        add(label1);
        add(panel);
    }
}